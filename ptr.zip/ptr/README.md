# Getting Started

# Product Tracking & Reporting (PTR) – Address Change Service (ACS) Forwarding

### Building application
./gradlew clean build

### Running application locally
./gradlew bootRun --args='--spring.profiles.active=local'


### Reference Documentation
For further reference, please consider the following sections:
