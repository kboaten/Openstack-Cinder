package gov.usps.ncoa.ptrclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PtrApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}

}
