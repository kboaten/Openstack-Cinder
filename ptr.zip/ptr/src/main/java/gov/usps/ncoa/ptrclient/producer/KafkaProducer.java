package gov.usps.ncoa.ptrclient.producer;

import gov.usps.ncoa.ptrclient.app.model.AcsPtr;
import gov.usps.ncoa.ptrclient.schema.AcsDisposition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class KafkaProducer {
    Logger logger = LoggerFactory.getLogger(KafkaProducer.class);

    @Autowired
    private StreamBridge streamBridge;

    public void publish(List<AcsPtr> acsInputData) {

        acsInputData.stream().forEach(acs -> {
            try {
                final AcsDisposition.Builder builder = AcsDisposition.newBuilder();
                builder
                        .setRecordKey(acs.getRecordKeyTransmitDateUniqueSequence())
                        .setAcsAncilSvcEnd(acs.getAncillaryServiceOptionUsed())
                        .setAcsCoaNixFlag(acs.getCoaNixieFlag())
                        .setAcsDnf(acs.getDeliverablilityCode())
                        .setDisp(acs.getActionCode())
                        .setAcsMailClass(acs.getMailClass())
                        .setEventZip(acs.getZipCode())
                        .setMid(acs.getMailerIdImpb())
                        .setGenSiteId(acs.getGeneratingSiteId())
                        .setImpbFromAcs(acs.getIMpbacs())
                        .setImpbFromPtr(acs.getIMpbptr())
                        .setPtrEventCode(acs.getPtrEventCode())
                        .setShipFileMailClass(acs.getSfMailClass())
                        .setTransactionDate(acs.getTransactionDate() + acs.getTransactionTime());
                AcsDisposition payload = builder.build();
                Message<AcsDisposition> message = MessageBuilder.withPayload(payload)
                        .setHeader(KafkaHeaders.KEY, payload.getRecordKey())
                        .build();
                streamBridge.send("output-out-0", message);
            } catch (Exception e) {
                logger.error("Failed publishing event. RecordKey: {} Error Message: {}", acs.getRecordKeyTransmitDateUniqueSequence(),
                        e.getMessage(), e);
            }
        });
    }

}
