package gov.usps.ncoa.ptrclient.app.model;


import lombok.Data;


@Data

public class AcsPtr {


    private String recordKeyTransmitDateUniqueSequence;


    private String ptrEventCode;


    private String iMpbptr;


    private String iMpbacs;


    private String mailerIdImpb;


    private String generatingSiteId;


    private String transactionDate;


    private String transactionTime;


    private String sfMailClass;


    private String mailClass;


    private String ancillaryServiceOptionUsed;


    private String coaNixieFlag;


    private String deliverablilityCode;


    private String actionCode;


    private String zipCode;


    private String filter;


}

