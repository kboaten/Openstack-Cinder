package gov.usps.ncoa.ptrclient.controller;

import gov.usps.ncoa.ptrclient.app.model.AcsPtr;
import gov.usps.ncoa.ptrclient.producer.KafkaProducer;
import gov.usps.ncoa.ptrclient.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;

@RestController
public class StatusController {

    @Autowired
    private EmailService emailService;

    @Autowired
    KafkaProducer kafkaProducer;

    @GetMapping("/status")
    public String status() {
        AcsPtr acs = new AcsPtr();
        acs.setRecordKeyTransmitDateUniqueSequence("887877544");
        acs.setActionCode("ActionCode");
        acs.setIMpbacs("IMpbacs");
        acs.setCoaNixieFlag("CoaNixieFlag");
        acs.setTransactionDate("20240506");
        acs.setTransactionTime("0244");
        acs.setIMpbptr("IMpbptr");
        acs.setDeliverablilityCode("DeliverablilityCode");
        acs.setAncillaryServiceOptionUsed("AncillaryServiceOptionUsed");
        acs.setGeneratingSiteId("GeneratingSiteId");
        acs.setMailClass("MailClass");
        acs.setPtrEventCode("EventCode");
        acs.setSfMailClass("setSfMailClass");
        acs.setZipCode("ZipCode");
        acs.setMailerIdImpb("MailerIdImpb");

        kafkaProducer.publish(Arrays.asList(acs));


        emailService.send("Test Kafka publish","Completed ");

        return "success";
    }

}
