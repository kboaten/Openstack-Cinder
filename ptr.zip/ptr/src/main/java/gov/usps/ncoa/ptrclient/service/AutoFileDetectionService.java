package gov.usps.ncoa.ptrclient.service;

import gov.usps.ncoa.ptrclient.producer.KafkaProducer;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;

@Service
public class AutoFileDetectionService {

    Logger logger = LoggerFactory.getLogger(AutoFileDetectionService.class);

    @Value("${source.directory}")
    String sourceDirectory;

    @Autowired
    KafkaProducer kafkaProducer;

//    @Autowired
//    FileParser fileParser;

    @PostConstruct
    public void init() {
        logger.debug("AutoFileDetectionService.init called");
        try {
            this.fileDetection();
        } catch (Exception e) {
            logger.error("File auto detection failed. Message: {}", e.getMessage(), e);
        }
    }

    /**
     * Watch sourceDirectory and pick up any new files dropped into it
     */
    public void fileDetection() throws IOException, InterruptedException {
        logger.debug("called fileDetection");
        WatchService watchService = FileSystems.getDefault().newWatchService();

        //Create a path object for sourceDirectory
        Path path = Paths.get(sourceDirectory);
        path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_MODIFY);

        WatchKey key;
        while ((key = watchService.take()) != null) {
            logger.debug("Detected a file change in directory: {}", sourceDirectory);
            for (WatchEvent<?> event : key.pollEvents()) {
                if (event.kind() == StandardWatchEventKinds.OVERFLOW) {
                    continue;
                }
                Path detectedFile = path.resolve(((WatchEvent<Path>) event).context());
                logger.debug("File detected. Filename: {}", detectedFile.toString());
               // kafkaProducer.publish(fileParser.parseFile(detectedFile.toString()));
            }
            if (!key.reset()) {
                break;
            }
            ;
        }
    }


}
