package gov.usps.ncoa.ptrclient.config;

import gov.usps.ncoa.ptrclient.schema.AcsDisposition;
import org.apache.kafka.common.protocol.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.support.ErrorMessage;

import java.util.function.Consumer;

@Configuration
public class ErrorConfig {
    Logger logger = LoggerFactory.getLogger(ErrorConfig.class);

//    @Bean
//    public Consumer<Message> acsDispositionStreamErrorHandler() {
//        return errorMessage -> {
//            errorMessage.
//            logger.error("Handling error message ", errorMessage);
//        };
//    }

    @Bean
    public Consumer<ErrorMessage> acsDispositionStreamErrorHandler() {
        return v -> {
            org.springframework.messaging.Message msg = v.getOriginalMessage();
            AcsDisposition acsDisposition = (AcsDisposition) msg.getPayload();
            logger.error("Error encountered - RecordKey: {} Error Message: {}",acsDisposition.getRecordKey(),
                    v.getPayload());
        };
    }
}
